package com.onlinemail.action;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.onlinemail.bean.BookType;
import com.onlinemail.bean.User;
import com.onlinemail.service.BookTypeService;
import com.onlinemail.service.UserService;

@Controller
public class UserAction {
	@Autowired
	private UserService us;
	@Autowired
	private BookTypeService bts;
	public BookTypeService getBts() {
		return bts;
	}
	public void setBts(BookTypeService bts) {
		this.bts = bts;
	}
	public UserService getUs() {
		return us;
	}
	public void setUs(UserService us) {
		this.us = us;
	}
	
	@RequestMapping("/getUsers")
	public String getUsers(HttpServletRequest request) {
		List<User> list = us.getAllUser();
		request.getSession().setAttribute("list", list);
		return "redirect:/admin/users.jsp";
	}
	@RequestMapping("/deleteUser")
	public String deleteUser(HttpServletRequest request,int id) {
		String msg = "ɾ���û��ɹ���";
		request.getSession().setAttribute("msg", msg);
		us.deleteUser(id);
		return "redirect:/admin/success.jsp";
	}
	@RequestMapping("/userLogin")
	public String userLodin(String username,String password,HttpServletRequest request) {
		User user = us.getUserByNamePsd(username, password);
		List<BookType> list = bts.getBookTypes();
		if(user==null) {
			String msg="�û������������";
			request.getSession().setAttribute("logMsg", msg);
			return "redirect:/user/login.jsp";
		}else {
			request.getSession().setAttribute("user", user);
			return "redirect:/user/index.jsp";
		}
	}
	@RequestMapping("/addUser")
	public String addUser(String username,String password,String email,String repassword,@RequestParam MultipartFile userimg,HttpServletRequest request) throws IOException {
		String msg = (String) request.getSession().getAttribute("msg");
		if(msg!=null) {
			msg=null;
		}
		if(password.equals(repassword)) {
			User dbUser = us.getUserByName(username);
			if(dbUser != null) {
				msg="�û����ѱ�ע�ᣡ";
				request.getSession().setAttribute("signmsg", msg);
			}else {
				User user = new User();
				user.setUsername(username);
				user.setUserPassword(password);
				user.setUserEmail(email);
				if(!userimg.isEmpty()) {
					//�ļ���
					String name = userimg.getName();
					String originalFilename = userimg.getOriginalFilename();
					if(originalFilename!=null && !name.equals("")) {
						String filename=originalFilename.substring(originalFilename.lastIndexOf("\\")+1);
						byte[] bytes = userimg.getBytes();
						String realPath = request.getServletContext().getRealPath("/images");
						user.setUserimg("../images/"+filename);
						File file = new File(realPath+"\\"+filename);
						FileOutputStream fos = new FileOutputStream(file);
						fos.write(bytes);
						fos.flush();
						fos.close();
					}
				}
				msg="ע��ɹ���";
				request.getSession().setAttribute("signmsg", msg);
				us.save(user);
			}
		}else {
			msg="�������벻һ��";
			request.getSession().setAttribute("signmsg", msg);
		}
		return "redirect:/user/login.jsp";
	}
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		User user = null;
		request.getSession().setAttribute("user", user);
		return "redirect:user/index.jsp";
	}
	@RequestMapping("/changeInformation")
	public String ChangeInformation(HttpServletRequest request,int id) {
		User user = us.getUserById(id);
		request.getSession().setAttribute("user", user);
		return "redirect:user/editorUser.jsp";
	}
	@RequestMapping("/editorUser")
	public String editorUser(User user,int userid,HttpServletRequest request,String repassword,@RequestParam MultipartFile img) throws IOException {
		String msg = null;
		user.setUserId(userid);
		if(user.getUserPassword().equals(repassword)) {
			User dbUser = us.getUserByName(user.getUsername());
			if(dbUser.getUserId().equals(user.getUserId()) || dbUser==null) {
				if(!img.isEmpty()) {
					//�ļ���
					String name = img.getName();
					String originalFilename = img.getOriginalFilename();
					if(originalFilename!=null && !name.equals("")) {
						String filename=originalFilename.substring(originalFilename.lastIndexOf("\\")+1);
						byte[] bytes = img.getBytes();
						String realPath = request.getServletContext().getRealPath("/images");
						user.setUserimg("../images/"+filename);
						File file = new File(realPath+"\\"+filename);
						FileOutputStream fos = new FileOutputStream(file);
						fos.write(bytes);
						fos.flush();
						fos.close();
					}
				}else {
					user.setUserimg(dbUser.getUserimg());
				}
				us.updateUser(user);
				msg="�û���Ϣ�Ѹ��ģ�";
				request.getSession().setAttribute("user", user);
				request.getSession().setAttribute("editorMsg", msg);
			}else {
				msg = "�û����Ѵ��ڣ�";
				request.getSession().setAttribute("editorMsg", msg);
			}
		}else {
			msg = "�������벻һ��";
			request.getSession().setAttribute("editorMsp", msg);
		}
		return "redirect:user/editorUser.jsp";
	}
}
