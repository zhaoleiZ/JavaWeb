package com.onlinemail.action;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.onlinemail.bean.Admin;
import com.onlinemail.service.AdminService;

@Controller
public class AdminAction {
	@Autowired
	private AdminService as;
	public AdminService getAs() {
		return as;
	}

	public void setAs(AdminService as) {
		this.as = as;
	}
	@RequestMapping("/login")
	public String login(String name,String password,HttpServletRequest request) {
		if(as.findByNamePsd(name, password)) {
			request.getSession().setAttribute("admin", name);
			return "redirect:/admin/index.jsp";
		}else {
			String msg = "�û������������...";
			request.getSession().setAttribute("error",msg);
			String buttonMsg="���µ�¼";
			request.getSession().setAttribute("button",buttonMsg);
			return "redirect:/admin/404.jsp";
		}
	}
	@RequestMapping("/registration")
	public String registration(String name,String password,String rePassword,Model model) {
		String msg = "ע��ʧ�ܣ�";
		Admin admin = new Admin();
		if(password.equals(rePassword)){
			admin.setAdminName(name);
			admin.setAdminPassword(password);
			as.addAdmin(admin);
			return "redirect:/admin/login.jsp";
		}
		model.addAttribute("error",msg);
		return "redirect:/admin/404.jsp";
	}
}
