package com.onlinemail.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.Order;
import com.onlinemail.bean.OrderDetail;
import com.onlinemail.bean.User;
import com.onlinemail.service.BookService;
import com.onlinemail.service.OrderDetailService;
import com.onlinemail.service.OrderService;
import com.onlinemail.service.UserService;

@Controller
public class ShoppingCarAction {
	@Autowired
	private BookService bs;
	@Autowired
	private UserService us;
	@Autowired
	private OrderService os;
	@Autowired
	private OrderDetailService ods;
	public OrderDetailService getOds() {
		return ods;
	}
	public void setOds(OrderDetailService ods) {
		this.ods = ods;
	}
	public OrderService getOs() {
		return os;
	}
	public void setOs(OrderService os) {
		this.os = os;
	}
	public BookService getBs() {
		return bs;
	}
	public void setBs(BookService bs) {
		this.bs = bs;
	}
	public UserService getUs() {
		return us;
	}
	public void setUs(UserService us) {
		this.us = us;
	}

	@RequestMapping("/addToCar")
	public String addToCat(HttpServletRequest request,int id,int userId) {
		User user = us.getUserById(userId);
		Order order = null;
		if(os.getUnpaidOrder(user)!=null) {
			order = os.getUnpaidOrder(user);
		}else {
			order = new Order();
			order.setOrderId(os.getMaxOrderId()+1);
			order.setUser(user);
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
			order.setOrderTime(df.format(new Date()));
			order.setState("δ����");
			os.saveOrder(order);
		}
		Book book = bs.findById(id);
		OrderDetail od = new OrderDetail();
		if(ods.getDetailByOrderAndBook(order, book)!=null) {
			od = ods.getDetailByOrderAndBook(order, book);
			int count = od.getCount();
			od.setCount(++count);
			ods.updateDetail(od);
		}else {
			od.setBook(book);
			od.setOrder(order);
			od.setCount(1);
			ods.saveDetail(od);
		}
		return "redirect:getAllBook.do";
	}
	@RequestMapping("/showCar")
	public String showCar(HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		Order order = os.getUnpaidOrder(user);
		request.getSession().setAttribute("order", order);
		if(order!=null) {
			List<OrderDetail> list = ods.getByOrderId(order);
			request.getSession().setAttribute("list",list);
			double price = 0;
			for(int i=0;i<list.size();i++) {
				price += list.get(i).getBook().getPrice()*list.get(i).getCount();
			}
			request.getSession().setAttribute("price", price);
			request.getSession().setAttribute("orderId", list.get(0).getOrder().getOrderId());
		}
		return "redirect:user/shoppingCar.jsp";
	}
	@RequestMapping("/addBookCount")
	public String addBookCount(int id) {
		OrderDetail od = ods.getByDetailId(id);
		int count = od.getCount();
		od.setCount(++count);
		ods.updateDetail(od);
		return "redirect:showCar.do";
	}
	@RequestMapping("/reduceBookCount")
	public String reduceBookCount(int id) {
		OrderDetail od = ods.getByDetailId(id);
		int count = od.getCount();
		Order order = od.getOrder();
		System.out.println("ShoppingCarAction order:"+order.getOrderId());
		if(od.getCount()>1) {
			od.setCount(--count);
			ods.updateDetail(od);
			if(ods.getByOrderId(order).isEmpty()) {
				os.deleteOrder(order);
			}
		}else {
			if(ods.getByOrderId(order).size()>1) {
				ods.deleteDetail(od);
			}else {
				os.deleteOrder(order);
			}
		}
		return "redirect:showCar.do";
	}
	@RequestMapping("/payOrder")
	public String payOrder(int id,HttpServletRequest request) {
		Order order = os.getOrderById(id);
		order.setState("�Ѹ���");
		os.updateOrder(order);
		request.getSession().setAttribute("paySuccess", "֧���ɹ���");
		return "redirect:user/success.jsp";
	}
	@RequestMapping("/deleteBookFromCar")
	public String deleteBookFromCar(int id,HttpServletRequest request,@RequestParam(value = "position[]", required = false) int[] positions) {
		List<OrderDetail> list = (List<OrderDetail>) request.getSession().getAttribute("list");
		Order order = os.getOrderById(id);
		if(list.size()==positions.length) {
			os.deleteOrder(order);
		}else {
			for(int i=0;i<positions.length;i++) {
				OrderDetail od = ods.getByDetailId(positions[i]);
				ods.deleteDetail(od);
			}
		}
		return "redirect:showCar.do";
	}
}
