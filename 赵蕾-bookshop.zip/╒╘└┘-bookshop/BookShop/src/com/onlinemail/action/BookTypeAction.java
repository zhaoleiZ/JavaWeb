package com.onlinemail.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.BookType;
import com.onlinemail.service.BookTypeService;

@Controller
public class BookTypeAction {
	@Autowired
	private BookTypeService bts;
	public BookTypeService getBts() {
		return bts;
	}
	public void setBts(BookTypeService bts) {
		this.bts = bts;
	}
	
	
	@RequestMapping("/getBookTypes")
	public String getBookTypes(HttpServletRequest request) {
		List<BookType> list = bts.getBookTypes();
		request.getSession().setAttribute("typeList",list);
		return "redirect:/admin/addBook.jsp";
	}
	@RequestMapping("/addBookType")
	public String addBookType(HttpServletRequest request,BookType bt) {
		String msg = (String) request.getSession().getAttribute("msg");
		if(msg!=null) {
			msg=null;
		}
		msg="ͼ���������ӳɹ���";
		request.getSession().setAttribute("msg", msg);
		bt.setTypeName(request.getParameter("type"));
		bts.addBookType(bt);
		return "redirect:/admin/success.jsp";
	}

}
