package com.onlinemail.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.onlinemail.bean.Order;
import com.onlinemail.bean.OrderDetail;
import com.onlinemail.bean.User;
import com.onlinemail.service.OrderService;
import com.onlinemail.service.UserService;

@Controller
public class OrderAction {
	@Autowired
	UserService us;
	@Autowired
	OrderService os;	
	public UserService getUs() {
		return us;
	}
	public void setUs(UserService us) {
		this.us = us;
	}
	public OrderService getOs() {
		return os;
	}
	public void setOs(OrderService os) {
		this.os = os;
	}
	@RequestMapping("/getOrders")
	public String getOrders(HttpServletRequest request,int id) {
		User user = us.getUserById(id);
		List<Order> list = os.getOrderByUserid(id);
		request.getSession().setAttribute("orderList", list);
		request.getSession().setAttribute("user", user);
		request.getSession().setAttribute("size", list.size());
		return "redirect:/admin/order.jsp";
	}
	@RequestMapping("/userGetOrders")
	public String userGetOrders(HttpServletRequest request,int id) {
		User user = (User) request.getSession().getAttribute("user");
		if(user==null) {
			user = us.getUserById(id);
		}
		List<Order> list = os.getOrderByUserid(id);
		System.out.println("OrderAction size:"+list.size());
		if(list.size()==0) {
			String msg = "����û�ж���...";
			request.getSession().setAttribute("orderMsg", msg);
		}
		request.getSession().setAttribute("orderList", list);
		request.getSession().setAttribute("user", user);
		request.getSession().setAttribute("size", list.size());
		return "redirect:/user/order.jsp";
	}
	@RequestMapping("/getAllOrders")
	public String getAllOrders(HttpServletRequest request) {
		List<Order> list = os.getOrderList();
		request.getSession().setAttribute("orderList", list);
		request.getSession().setAttribute("size", list.size());
		return "redirect:admin/allOrders.jsp";
	}
	@RequestMapping("/cancelOrder")
	public String cancelOrder(HttpServletRequest request,int id) {
		Order order = os.getOrderById(id);
		order.setState("����ȡ��");
		os.updateOrder(order);
		User user = (User) request.getSession().getAttribute("user");
		return "redirect:userGetOrders.do?id="+user.getUserId();
	}
	@RequestMapping("/deleteOrder")
	public String deleteOrder(HttpServletRequest request,int id) {
		Order order = os.getOrderById(id);
		os.deleteOrder(order);
		User user = (User) request.getSession().getAttribute("user");
		return "redirect:userGetOrders.do?id="+user.getUserId();
	}
	@RequestMapping("/searchOrder")
	public String searchOrder(HttpServletRequest request,String state) {
		request.getSession().setAttribute("state", state);
		List<Order> list = os.selectByState(state);
		System.out.println("OrderAction:"+list.size());
		request.getSession().setAttribute("list", list);
		request.getSession().setAttribute("size", list.size());
		return "redirect:admin/orderState.jsp";
	}
}
