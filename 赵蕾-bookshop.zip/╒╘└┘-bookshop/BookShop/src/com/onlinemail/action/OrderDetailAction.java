package com.onlinemail.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.Order;
import com.onlinemail.bean.OrderDetail;
import com.onlinemail.bean.User;
import com.onlinemail.service.OrderDetailService;
import com.onlinemail.service.OrderService;

@Controller
public class OrderDetailAction {
	@Autowired
	private OrderDetailService ods;
	@Autowired
	private OrderService os;
	public OrderDetailService getOds() {
		return ods;
	}
	public void setOds(OrderDetailService ods) {
		this.ods = ods;
	}
	public OrderService getOs() {
		return os;
	}
	public void setOs(OrderService os) {
		this.os = os;
	}
	@RequestMapping("/getOrderDetail")
	public String getOrderDetail(HttpServletRequest request,int id) {
		Order order = os.getOrderById(id);
		List<OrderDetail> list= ods.getByOrderId(order);
		request.getSession().setAttribute("list", list);
		double price = 0;
		for(int i=0;i<list.size();i++) {
			price+=list.get(i).getCount()*list.get(i).getBook().getPrice();
		}
		request.getSession().setAttribute("price", price);
		return "redirect:/admin/orderDetail.jsp";
	}
	@RequestMapping("/userGetOrderDetail")
	public String userGetOrderDetail(HttpServletRequest request,int id) {
		Order order = os.getOrderById(id);
		List<OrderDetail> list= ods.getByOrderId(order);
		request.getSession().setAttribute("list", list);
		double price = 0;
		for(int i=0;i<list.size();i++) {
			price+=list.get(i).getCount()*list.get(i).getBook().getPrice();
		}
		request.getSession().setAttribute("price", price);
		return "redirect:/user/orderDetail.jsp";
	}
}
