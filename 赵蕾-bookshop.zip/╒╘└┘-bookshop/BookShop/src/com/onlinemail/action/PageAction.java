package com.onlinemail.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.BookType;
import com.onlinemail.bean.Page;
import com.onlinemail.service.BookService;

@Controller
public class PageAction {
	@Autowired
	private BookService bs;
	public BookService getBs() {
		return bs;
	}
	public void setBs(BookService bs) {
		this.bs = bs;
	}

	@RequestMapping("/search")
	public String search(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Object att = session.getAttribute("books");
		List<Book> list = null;
		if(att==null) {
			list = bs.getBooks();
			session.setAttribute("books", list);
		}else {
			list=(List<Book>)att;
		}
		String pages = request.getParameter("page");
		Integer dpage=1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(list.size());
		page.setTotalpage();
		page.setDpage(dpage);
		Integer end = dpage*page.getPagecount();
		if(end>page.getTotalcount()) {
			end = page.getTotalcount();
		}
		List<Book> subList = list.subList((dpage-1)*page.getPagecount(), end);
		request.getSession().setAttribute("bookList", subList);
		request.getSession().setAttribute("page", page);
		
		return "redirect:/admin/gallery.jsp";
	}
	@RequestMapping("/allBookSreach")
	public String allBookSearch(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Object att = session.getAttribute("books");
		List<Book> list = null;
		if(att==null) {
			list = bs.getBooks();
			session.setAttribute("books", list);
		}else {
			list=(List<Book>)att;
		}
		String pages = request.getParameter("page");
		Integer dpage=1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(list.size());
		page.setTotalpage();
		page.setDpage(dpage);
		Integer end = dpage*page.getPagecount();
		if(end>page.getTotalcount()) {
			end = page.getTotalcount();
		}
		List<Book> subList = list.subList((dpage-1)*page.getPagecount(), end);
		request.getSession().setAttribute("bookList", subList);
		request.getSession().setAttribute("page", page);
		
		return "redirect:/user/allBooks.jsp";
	}
	@RequestMapping("/timeSearch")
	public String timeSearch(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Object att = session.getAttribute("timeBook");
		List<Book> list = null;
		if(att==null) {
			list = bs.getBooksByTime();
			session.setAttribute("timeBook", list);
		}else {
			list=(List<Book>)att;
		}
		String pages = request.getParameter("page");
		Integer dpage=1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(list.size());
		page.setTotalpage();
		page.setDpage(dpage);
		Integer end = dpage*page.getPagecount();
		if(end>page.getTotalcount()) {
			end = page.getTotalcount();
		}
		List<Book> subList = list.subList((dpage-1)*page.getPagecount(), end);
		request.getSession().setAttribute("bookList", subList);
		request.getSession().setAttribute("page", page);
		
		return "redirect:/user/byTime.jsp";
	}
	@RequestMapping("/higherSearch")
	public String higherSearch(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Object att = session.getAttribute("highBook");
		List<Book> list = null;
		if(att==null) {
			list = bs.getBooksByHigherPrice();
			session.setAttribute("highBook", list);
		}else {
			list=(List<Book>)att;
		}
		String pages = request.getParameter("page");
		Integer dpage=1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(list.size());
		page.setTotalpage();
		page.setDpage(dpage);
		Integer end = dpage*page.getPagecount();
		if(end>page.getTotalcount()) {
			end = page.getTotalcount();
		}
		List<Book> subList = list.subList((dpage-1)*page.getPagecount(), end);
		request.getSession().setAttribute("bookList", subList);
		request.getSession().setAttribute("page", page);
		
		return "redirect:/user/byHigher.jsp";
	}
	@RequestMapping("/lowerSearch")
	public String lowerSearch(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Object att = session.getAttribute("lowerBook");
		List<Book> list = null;
		if(att==null) {
			list = bs.getBooksByLowerPrice();
			session.setAttribute("lowerBook", list);
		}else {
			list=(List<Book>)att;
		}
		String pages = request.getParameter("page");
		Integer dpage=1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(list.size());
		page.setTotalpage();
		page.setDpage(dpage);
		Integer end = dpage*page.getPagecount();
		if(end>page.getTotalcount()) {
			end = page.getTotalcount();
		}
		List<Book> subList = list.subList((dpage-1)*page.getPagecount(), end);
		request.getSession().setAttribute("bookList", subList);
		request.getSession().setAttribute("page", page);
		
		return "redirect:/user/byLower.jsp";
	}
}
