package com.onlinemail.action;

import java.util.ArrayList;
import java.util.List;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.BookType;
import com.onlinemail.bean.Page;
import com.onlinemail.service.BookService;
import com.onlinemail.service.BookTypeService;

@Controller
public class BookAction {
	@Autowired
	private BookService bs;
	public BookService getBs() {
		return bs;
	}
	public void setBs(BookService bs) {
		this.bs = bs;
	}
	@Autowired
	private BookTypeService bts;	
	public BookTypeService getBts() {
		return bts;
	}
	public void setBts(BookTypeService bts) {
		this.bts = bts;
	}
	
	@RequestMapping("/getBooks")
	public String getBooks(HttpServletRequest request) {
		String pages = request.getParameter("page");
		Integer dpage = 1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(bs.getBookCount());
		page.setTotalpage();
		page.setDpage(dpage);
		List<Book> list=bs.selectByPage(page);
		request.getSession().setAttribute("bookList", list);
		request.getSession().setAttribute("page", page);
		return "redirect:/admin/gallery.jsp";
	}
	@RequestMapping("/getThisBook")
	public String getThisBook(int id,HttpServletRequest request) {
		List<BookType> list = bts.getBookTypes();
		Book book = bs.findById(id);
		request.getSession().setAttribute("typeList",list);
		request.getSession().setAttribute("book",book);
		return "redirect:/admin/editorBook.jsp";
	}
	@RequestMapping("/editorBook")
	public String editorBook(Book book,@RequestParam MultipartFile bookimg,HttpServletRequest request) throws IOException {
		String msg = (String) request.getSession().getAttribute("msg");
		if(msg!=null) {
			msg=null;
		}
		msg = "�޸ĳɹ���";
		request.getSession().setAttribute("msg", msg);
		Book book1 = bs.findById(book.getId());
		if(book.getImages()==null) {
			book.setImages(book1.getImages());
		}
		if(!bookimg.isEmpty()) {
			//�ļ���
			String name = bookimg.getName();
			String originalFilename = bookimg.getOriginalFilename();
			if(originalFilename!=null && !name.equals("")) {
				String filename=originalFilename.substring(originalFilename.lastIndexOf("\\")+1);
				byte[] bytes = bookimg.getBytes();
				String realPath = request.getServletContext().getRealPath("/images");
				book.setImages("../images/"+filename);
				File file = new File(realPath+"\\"+filename);
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(bytes);
				fos.flush();
				fos.close();
			}
		}
		int typeId = Integer.parseInt(request.getParameter("type"));
		BookType bt = bts.getById(typeId);
		book.setBookType(bt);
		bs.editorBook(book);
		return "redirect:/admin/success.jsp";
	}
	@RequestMapping("/addBook")
	public String addBook(HttpServletRequest request,@RequestParam MultipartFile bookimg,Book book) throws IOException {
		String msg = (String) request.getSession().getAttribute("msg");
		if(msg!=null) {
			msg=null;
		}
		msg="���ӳɹ���";
		request.getSession().setAttribute("msg", msg);
		int typeId = Integer.parseInt(request.getParameter("type"));
		BookType bt = bts.getById(typeId);
		book.setBookType(bt);
		String data = request.getParameter("data");
		book.setData(data);
		if(!bookimg.isEmpty()) {
			//�ļ���
			String name = bookimg.getName();
			String originalFilename = bookimg.getOriginalFilename();
			if(originalFilename!=null && !name.equals("")) {
				String filename=originalFilename.substring(originalFilename.lastIndexOf("\\")+1);
				byte[] bytes = bookimg.getBytes();
				String realPath = request.getServletContext().getRealPath("/images");
				book.setImages("../images/"+filename);
				File file = new File(realPath+"\\"+filename);
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(bytes);
				fos.flush();
				fos.close();
			}
		}
		bs.saveBook(book);
		return "redirect:/admin/success.jsp";
	}
	@RequestMapping("/deleteBook")
	public String deleteBook(int id,HttpServletRequest request) {
		String msg = (String) request.getSession().getAttribute("msg");
		if(msg!=null) {
			msg=null;
		}
		Book book = new Book();
		book.setId(id);
		bs.deleteBook(book);
		msg = "ɾ���ɹ���";
		request.getSession().setAttribute("msg", msg);
		return "redirect:/admin/success.jsp";
	}
	@RequestMapping("/getBooksByType")
	public String getBooksByType(int id,HttpServletRequest request) {
		List<Book> list = bs.getBooksByTypeId(id);
		int size = list.size();
		request.getSession().setAttribute("size",size);
		request.getSession().setAttribute("bookList", list);
		return "redirect:/user/typeList.jsp";
	}
	@RequestMapping("/getBookDetail")
	public String getBookDetail(int id,HttpServletRequest request) {
		Book book = bs.findById(id);
		request.getSession().setAttribute("book", book);
		return "redirect:user/bookDetail.jsp";
	}
	@RequestMapping("/searchBook")
	public String searchBook(String name,HttpServletRequest request) {
		List<Book> list = bs.getBookByPartName(name);
		System.out.println("BookAction:"+list.size());
		request.getSession().setAttribute("size", list.size());
		return "redirect:user/searchBook.jsp";
	}
	@RequestMapping("/getAllBook")
	public String allBook(HttpServletRequest request) {
		String pages = request.getParameter("page");
		Integer dpage = 1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(bs.getBookCount());
		page.setTotalpage();
		page.setDpage(dpage);
		List<Book> list=bs.selectByPage(page);
		request.getSession().setAttribute("bookList", list);
		request.getSession().setAttribute("page", page);
		request.getSession().setAttribute("size", list.size());
		return "redirect:user/allBooks.jsp";
	}
	@RequestMapping("/listByHot")
	public String listByHot(HttpServletRequest request) {
		String pages = request.getParameter("page");
		Integer dpage = 1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(bs.getBookCount());
		page.setTotalpage();
		page.setDpage(dpage);
		List<Book> list=bs.selectByPageHot(page);
		request.getSession().setAttribute("bookList", list);
		request.getSession().setAttribute("page", page);
		request.getSession().setAttribute("size", list.size());
		return "redirect:user/byHot.jsp";
	}
	@RequestMapping("/listByTime")
	public String listByTime(HttpServletRequest request) {
		String pages = request.getParameter("page");
		Integer dpage = 1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(bs.getBookCount());
		page.setTotalpage();
		page.setDpage(dpage);
		List<Book> list=bs.selectByPageTime(page);
		request.getSession().setAttribute("bookList", list);
		request.getSession().setAttribute("page", page);
		request.getSession().setAttribute("size", list.size());
		return "redirect:user/byTime.jsp";
	}
	@RequestMapping("/listByLowerPrice")
	public String listByLowerPrice(HttpServletRequest request) {
		String pages = request.getParameter("page");
		Integer dpage = 1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(bs.getBookCount());
		page.setTotalpage();
		page.setDpage(dpage);
		List<Book> list=bs.selectByPageLower(page);
		request.getSession().setAttribute("bookList", list);
		request.getSession().setAttribute("page", page);
		request.getSession().setAttribute("size", list.size());
		return "redirect:user/byLower.jsp";
	}
	@RequestMapping("/listByHigherPrice")
	public String listByHigherPrice(HttpServletRequest request) {
		String pages = request.getParameter("page");
		Integer dpage = 1;
		if(pages!=null) {
			dpage = Integer.parseInt(pages);
		}
		Page page = new Page();
		page.setTotalcount(bs.getBookCount());
		page.setTotalpage();
		page.setDpage(dpage);
		List<Book> list=bs.selectByPageHigher(page);
		request.getSession().setAttribute("bookList", list);
		request.getSession().setAttribute("page", page);
		request.getSession().setAttribute("size", list.size());
		return "redirect:user/byHigher.jsp";
	}
	@RequestMapping("/adminSearchBook")
	public String adminSearchBook(HttpServletRequest request,String name) {
		List list = bs.getBookByPartName(name);
		request.getSession().setAttribute("bookList", list);
		return "redirect:admin/searchBook.jsp";
	}
}
