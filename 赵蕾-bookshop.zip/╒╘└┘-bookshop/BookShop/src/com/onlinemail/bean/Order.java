package com.onlinemail.bean;

import java.util.HashSet;
import java.util.Set;

public class Order {

	private int orderId;
	private String orderTime;
	private String state;
	//����״̬������ɣ���ȡ�����Ѹ��δ����
	private User user;//���һ
	private Set<OrderDetail> orderDetail = new HashSet<OrderDetail>();
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderTime() {
		return orderTime;
	}
	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Set<OrderDetail> getOrderDetail() {
		return orderDetail;
	}
	public void setOrderDetail(Set<OrderDetail> orderDetail) {
		this.orderDetail = orderDetail;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
