package com.onlinemail.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.onlinemail.Dao.BookDaoImpl;
import com.onlinemail.bean.Book;
import com.onlinemail.bean.BookType;
import com.onlinemail.bean.Page;

@Service
public class BookService {
	@Resource
	private BookDaoImpl bdi;
	public List<Book> getBooks(){
		return bdi.getBooks();
	}
	public List<Book> getBooksByTime(){
		return bdi.getBooksByTime();
	}
	public List<Book> getBooksByHigherPrice(){
		return bdi.getBooksByHigherPrice();
	}
	public List<Book> getBooksByLowerPrice(){
		return bdi.getBooksByLowerPrice();
	}
	public List<Book> getBookByPartName(String name){
		return bdi.getBookByPartName(name);
	}
	public boolean saveBook(Book book) {
		return bdi.addBook(book);
	}
	public boolean deleteBook(Book book) {
		return bdi.deleteBook(book);
	}
	public boolean editorBook(Book book) {
		return bdi.editorBook(book);
	}
	public Book findById(int id) {
		return bdi.findById(id);
	}
	public int getBookCount() {
		return bdi.getBookCount();
	}
	public List<Book> selectByPage(Page page){
		return bdi.selectByPage(page);
	}
	public List<Book> selectByPageTime(Page page){
		return bdi.selectByPageTime(page);
	}
	public List<Book> selectByPageHigher(Page page){
		return bdi.selectByPageHigher(page);
	}
	public List<Book> selectByPageLower(Page page){
		return bdi.selectByPageLower(page);
	}
	public List<Book> selectByPageHot(Page page){
		return bdi.selectByPageHot(page);
	}
	public List<Book> getBooksByTypeId(int id) {
		List<Book> bookList = bdi.getBooks();
		List<Book> list = new ArrayList<Book>();
		for(int i=0;i<bookList.size();i++) {
			if(bookList.get(i).getBookType().getTypeId()==id) {
				list.add(bookList.get(i));
			}
		}
		return list;
	}
	public Book getBookById(int id) {
		// TODO Auto-generated method stub
		return bdi.getBookById(id);
	}
}
