package com.onlinemail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinemail.Dao.OrderDaoImpl;
import com.onlinemail.bean.Order;
import com.onlinemail.bean.User;

@Service
public class OrderService {
	@Autowired
	private OrderDaoImpl odi;
	public OrderDaoImpl getOdi() {
		return odi;
	}
	public void setOdi(OrderDaoImpl odi) {
		this.odi = odi;
	}
	
	public List<Order> getOrderList(){
		return odi.getOrderList();
	}
	public List<Order> getOrderByUserid(int id){
		return odi.getOrderByUserId(id);
	}
	public User getUser(int id) {
		return odi.getUser(id);
	}
	public Order getOrderById(int id) {
		return odi.getOrderById(id);
	}
	public boolean updateOrder(Order order) {
		return odi.updateOrder(order);
	}
	public boolean deleteOrder(Order order) {
		return odi.deleteOrder(order);
	}
	public Order getUnpaidOrder(User user) {
		return odi.getUnpaidOrder(user);
	}
	public boolean saveOrder(Order order) {
		return odi.saveOrder(order);
	}
	public int getMaxOrderId() {
		return odi.getMaxOrderId();
	}
	public List<Order> selectByState(String state){
		return odi.selectByState(state);
	}
}
