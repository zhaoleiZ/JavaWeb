package com.onlinemail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinemail.Dao.UserDaoImpl;
import com.onlinemail.bean.User;

@Service
public class UserService {
	@Autowired
	private UserDaoImpl udi;
	public UserDaoImpl getUdi() {
		return udi;
	}
	public void setUdi(UserDaoImpl udi) {
		this.udi = udi;
	}
	
	public List<User> getAllUser(){
		return udi.getAllUser();
	}
	public User getUserById(int id) {
		return udi.getUserById(id);
	}
	public boolean deleteUser(int id) {
		return udi.deleteUser(id);
	}
	public User getUserByNamePsd(String name,String psd) {
		return udi.getUserByNamePsd(name, psd);
	}
	public boolean save(User user) {
		// TODO Auto-generated method stub
		return udi.save(user);
	}
	public User getUserByName(String username) {
		// TODO Auto-generated method stub
		return udi.getUserByName(username);
	}
	public boolean updateUser(User user) {
		return udi.updateUser(user);
	}
}
