package com.onlinemail.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.onlinemail.Dao.BookTypeDaoImpl;
import com.onlinemail.bean.BookType;

@Service
public class BookTypeService {
	@Resource
	private BookTypeDaoImpl btdi;
	
	public BookType getByName(String name) {
		return btdi.getByName(name);
	}
	public List<BookType> getBookTypes(){
		return btdi.getBookTypes();
	}
	public BookType getById(int id) {
		return btdi.getById(id);
	}
	public boolean addBookType(BookType bt) {
		return btdi.addBookType(bt);
	}
}
