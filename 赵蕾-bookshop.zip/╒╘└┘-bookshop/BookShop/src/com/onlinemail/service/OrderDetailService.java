package com.onlinemail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinemail.Dao.OrderDetailDaoImpl;
import com.onlinemail.bean.Book;
import com.onlinemail.bean.Order;
import com.onlinemail.bean.OrderDetail;

@Service
public class OrderDetailService {
	@Autowired
	private OrderDetailDaoImpl oddi;
	public OrderDetailDaoImpl getOddi() {
		return oddi;
	}
	public void setOddi(OrderDetailDaoImpl oddi) {
		this.oddi = oddi;
	}
	public List<OrderDetail> getByOrderId(Order order){
		return oddi.getByOrderId(order);
	}
	public OrderDetail getDetailByOrderAndBook(Order order,Book book) {
		return oddi.getDetailByOrderAndBook(order, book);
	}
	public boolean updateDetail(OrderDetail od) {
		return oddi.updateDetail(od);
	}
	public boolean saveDetail(OrderDetail od) {
		return oddi.saveDetail(od);
	}
	public OrderDetail getByDetailId(int detailId) {
		return oddi.getByDetailId(detailId);
	}
	public boolean deleteDetail(OrderDetail od) {
		return oddi.deleteDetail(od);
	}
}
