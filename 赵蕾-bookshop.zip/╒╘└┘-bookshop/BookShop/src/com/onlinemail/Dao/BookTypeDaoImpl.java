package com.onlinemail.Dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.BookType;

@Repository
public class BookTypeDaoImpl implements BookTypeDao {

	@Resource
	private SessionFactory sessionFactory;
	
	@Override
	public BookType getByName(String name) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BookType where typeName=?");
		query.setString(0, name);
		BookType bt = (BookType) query.uniqueResult();
		session.close();
		return bt;
	}

	@Override
	public List<BookType> getBookTypes() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BookType");
		List<BookType> list = query.list();
		session.close();
		return list;
	}

	@Override
	public BookType getById(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BookType where typeId=?");
		query.setInteger(0, id);
		BookType bt = (BookType) query.uniqueResult();
		session.close();
		return bt;
	}

	@Override
	public boolean addBookType(BookType bt) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(bt);
		tx.commit();
		session.close();
		return true;
	}

}
