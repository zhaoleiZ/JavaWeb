package com.onlinemail.Dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.onlinemail.bean.Order;
import com.onlinemail.bean.OrderDetail;
import com.onlinemail.bean.User;

@Repository
public class OrderDaoImpl implements OrderDao {
	@Resource
	private SessionFactory sessionFactory;
	private Transaction tx;
	public Transaction getTx() {
		return tx;
	}
	public void setTx(Transaction tx) {
		this.tx = tx;
	}

	@Override
	public List<Order> getOrderList() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Order");
		List<Order> list = query.list();
		return list;
	}
	@Override
	public List<Order> getOrderByUserId(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Order where userid=?");
		query.setInteger(0, id);
		List<Order> list = query.list();
		session.close();
		return list;
	}
	@Override
	public User getUser(int id) {
		// TODO Auto-generated method stub
		Session session =sessionFactory.openSession();
		Order order = session.get(Order.class, id);
		User user = order.getUser();
		session.close();
		return user;
	}
	@Override
	public Order getOrderById(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Order where orderId=?");
		query.setInteger(0, id);
		Order order = (Order) query.uniqueResult();
		session.close();
		return order;
	}
	public boolean updateOrder(Order order) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.update(order);
		tx.commit();
		session.close();
		return true;
	}
	public boolean deleteOrder(Order order) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		Query query = session.createQuery("from OrderDetail where order=?");
		query.setEntity(0, order);
		List<OrderDetail> list = query.list();
		for(int i=0;i<list.size();i++) {
			session.delete(list.get(i));
		}
		session.delete(order);
		tx.commit();
		session.close();
		return true;
	}
	@Override
	public Order getUnpaidOrder(User user) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Order where state='δ����' and user=?");
		query.setEntity(0, user);
		Order order = (Order) query.uniqueResult();
		System.out.println("OrderDao:"+order!=null);
		session.close();
		return order;
	}
	@Override
	public boolean saveOrder(Order order) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(order);
		tx.commit();
		session.close();
		return true;
	}
	public int getMaxOrderId() {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("select max(orderId) from Order");
		int id = (int)query.uniqueResult();
		session.close();
		return id;
	}
	public List<Order> selectByState(String state){
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Order where state=?");
		query.setString(0, state);
		List<Order> list = query.list();
		for(int i=0;i<list.size();i++) {
			System.out.println("OrderDaoImpl user:"+list.get(i).getUser().getUsername());
		}
		session.close();
		return list;
	}
}
