package com.onlinemail.Dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.onlinemail.bean.Admin;

@Repository
public class AdminDaoImpl implements AdminDao {

	@Resource
	private SessionFactory sessionFactory;
	private Transaction tx;
	@Override
	public List<Admin> findAll() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Admin");
		List<Admin> list = query.list();
		session.close();
		return list;
	}

	@Override
	public Admin findByNamePsd(String name, String psd) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Admin where name=? and password=?");
		query.setString(0, name);
		query.setString(1, psd);
		Admin admin = (Admin) query.uniqueResult();
		session.close();
        return admin;
	}

	@Override
	public boolean addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(admin);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public boolean updateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.update(admin);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public boolean deleteAdmin(Admin admin) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.delete(admin);
		tx.commit();
		session.close();
		return true;
	}

}
