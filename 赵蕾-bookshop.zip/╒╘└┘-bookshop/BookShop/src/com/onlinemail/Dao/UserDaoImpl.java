package com.onlinemail.Dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.onlinemail.bean.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Resource
	private SessionFactory sessionFactory;
	private Session getSession() {
		return sessionFactory.openSession();
	}
	private Transaction tx;
	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		Query query = getSession().createQuery("from User");
		List<User> list = query.list();
		return list;
	}
	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		Session session =sessionFactory.openSession();
		User user = session.get(User.class, id);	
		session.close();
		return user;
	}
	@Override
	public boolean deleteUser(int id) {
		// TODO Auto-generated method stub
		Session session =sessionFactory.openSession();
		tx=session.beginTransaction();
		User user = session.get(User.class, id);	
		session.delete(user);
		tx.commit();
		session.close();
		return true;
	}
	@Override
	public User getUserByNamePsd(String name, String psd) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where username=? and userPassword=?");
		query.setString(0, name);
		query.setString(1, psd);
		User user = (User) query.uniqueResult();
		session.close();
		return user;
	}
	public boolean save(User user) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx =session.beginTransaction();
		session.save(user);
		tx.commit();
		session.close();
		return true;
	}
	public User getUserByName(String username) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where username=?");
		query.setString(0, username);
		User user = (User)query.uniqueResult();
		session.close();
		return user;
	}
	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.update(user);
		tx.commit();
		session.close();
		return true;
	}

}
