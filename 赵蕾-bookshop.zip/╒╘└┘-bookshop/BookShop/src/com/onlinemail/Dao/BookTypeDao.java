package com.onlinemail.Dao;

import java.util.List;

import com.onlinemail.bean.BookType;

public interface BookTypeDao {
	public BookType getById(int id);
	public BookType getByName(String name);
	public List<BookType> getBookTypes();
	public boolean addBookType(BookType bt);
}
