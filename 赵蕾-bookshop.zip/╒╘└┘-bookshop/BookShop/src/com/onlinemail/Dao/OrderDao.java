package com.onlinemail.Dao;

import java.util.List;

import com.onlinemail.bean.Order;
import com.onlinemail.bean.User;

public interface OrderDao {
	public List<Order> getOrderList();
	public List<Order> getOrderByUserId(int id);
	public User getUser(int id);
	public Order getOrderById(int id);
	public boolean updateOrder(Order order);
	public boolean deleteOrder(Order order);
	public Order getUnpaidOrder(User user);
	public boolean saveOrder(Order order);
	public int getMaxOrderId();
	public List<Order> selectByState(String state);
}
