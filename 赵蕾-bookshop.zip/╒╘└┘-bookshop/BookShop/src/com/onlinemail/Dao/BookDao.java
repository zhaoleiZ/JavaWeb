package com.onlinemail.Dao;

import java.util.List;
import java.util.Map;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.Page;

public interface BookDao {
	public List<Book> getBooks();
	public List<Book> getBooksByTime();
	public List<Book> getBooksByHigherPrice();
	public List<Book> getBooksByLowerPrice();
	public List<Book> getBookByPartName(String name);
	public boolean addBook(Book book);
	public boolean deleteBook(Book book);
	public boolean editorBook(Book book);
	public Book findById(int id);
	public int getBookCount();
	public List<Book> selectByPage(Page page);
	public List<Book> selectByPageTime(Page page);
	public List<Book> selectByPageHigher(Page page);
	public List<Book> selectByPageLower(Page page);
	public List<Book> selectByPageHot(Page page);
	public Book getBookById(int id);
}
