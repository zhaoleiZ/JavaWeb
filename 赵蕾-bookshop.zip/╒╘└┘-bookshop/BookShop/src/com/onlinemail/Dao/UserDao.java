package com.onlinemail.Dao;

import java.util.List;

import com.onlinemail.bean.User;

public interface UserDao {
	public List<User> getAllUser();
	public User getUserById(int id);
	public boolean deleteUser(int id);
	public User getUserByNamePsd(String name,String psd);
	public boolean updateUser(User user);
}
