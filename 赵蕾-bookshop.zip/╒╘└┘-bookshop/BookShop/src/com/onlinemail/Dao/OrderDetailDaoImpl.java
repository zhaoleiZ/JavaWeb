package com.onlinemail.Dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.Order;
import com.onlinemail.bean.OrderDetail;

@Repository
public class OrderDetailDaoImpl implements OrderDetailDao {
	@Resource
	private SessionFactory sessionFactory;
	private Transaction tx;
	public Transaction getTx() {
		return tx;
	}
	public void setTx(Transaction tx) {
		this.tx = tx;
	}
	@Override
	public List<OrderDetail> getByOrderId(Order order) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from OrderDetail where order=?");
		query.setEntity(0, order);
		List<OrderDetail> list = query.list();
		for(int i=0;i<list.size();i++) {
			Book book = list.get(i).getBook();
			System.out.println("bookname:"+book.getName());
		}
		session.close();
		return list;
	}
	public OrderDetail getDetailByOrderAndBook(Order order,Book book) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from OrderDetail where order=? and book=?");
		query.setEntity(0, order);
		query.setEntity(1, book);
		OrderDetail od = (OrderDetail) query.uniqueResult();
		session.close();
		return od;
	}
	public boolean updateDetail(OrderDetail od) {
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.update(od);
		tx.commit();
		session.close();
		return true;
	}
	public boolean saveDetail(OrderDetail od) {
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(od);
		tx.commit();
		session.close();
		return true;
	}
	@Override
	public OrderDetail getByDetailId(int detailId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		OrderDetail od = session.get(OrderDetail.class, detailId);
		session.close();
		return od;
	}
	public boolean deleteDetail(OrderDetail od) {
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.delete(od);
		tx.commit();
		return true;
	}
}
