package com.onlinemail.Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.Page;

@Repository
public class BookDaoImpl implements BookDao {
	@Resource
	private SessionFactory sessionFactory;
	private Transaction tx;
	@Override
	public List<Book> getBooks() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book");
		List<Book> list = query.list();
		session.close();
		return list;
	}

	@Override
	public List<Book> getBooksByTime() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book order by id desc");
		List<Book> list = query.list();
		session.close();
		return list;
	}

	@Override
	public List<Book> getBooksByHigherPrice() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book order by price");
		List<Book> list = query.list();
		session.close();
		return list;
	}

	@Override
	public List<Book> getBooksByLowerPrice() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book order by price desc");
		List<Book> list = query.list();
		session.close();
		return list;
	}

	@Override
	public List<Book> getBookByPartName(String name) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book where name like ?");
		query.setString(0, "%"+name+"%");
		List<Book> list = query.list();
		session.close();
		return list;
	}

	@Override
	public boolean addBook(Book book) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(book);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public boolean deleteBook(Book book) {
		// TODO Auto-generated method stub
		Session session  = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.delete(book);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public boolean editorBook(Book book) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.update(book);
		tx.commit();
		session.close();
		return true;
	}
	@Override
	public Book findById(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Book book = session.get(Book.class, id);
		System.out.println("aaa:"+book.getBookType().getTypeName());
		session.close();
		return book;
	}

	@Override
	public int getBookCount() {
		// TODO Auto-generated method stub
		return getBooks().size();
	}

	@Override
	public List<Book> selectByPage(Page page) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book");
		List<Book> list = query.setFirstResult((page.getDpage()-1)*page.getPagecount())
				.setMaxResults(page.getPagecount()).list();
		session.close();
		return list;
	}
	
	@Override
	public List<Book> selectByPageTime(Page page) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book order by id desc");
		List<Book> list = query.setFirstResult((page.getDpage()-1)*page.getPagecount())
				.setMaxResults(page.getPagecount()).list();
		session.close();
		return list;
	}

	@Override
	public List<Book> selectByPageHigher(Page page) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book order by price desc");
		List<Book> list = query.setFirstResult((page.getDpage()-1)*page.getPagecount())
				.setMaxResults(page.getPagecount()).list();
		session.close();
		return list;
	}
	
	@Override
	public List<Book> selectByPageLower(Page page) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book order by price");
		List<Book> list = query.setFirstResult((page.getDpage()-1)*page.getPagecount())
				.setMaxResults(page.getPagecount()).list();
		session.close();
		return list;
	}

	public Book getBookById(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Book where id=?");
		query.setInteger(0, id);
		Book book = (Book) query.uniqueResult();
		session.close();
		return book;
	}

	@Override
	public List<Book> selectByPageHot(Page page) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("select book from OrderDetail as od group by od.book order by od.count desc");
		List<Book> list = query.setFirstResult((page.getDpage()-1)*page.getPagecount())
				.setMaxResults(page.getPagecount()).list();
		session.close();
		return list;
	}
}
