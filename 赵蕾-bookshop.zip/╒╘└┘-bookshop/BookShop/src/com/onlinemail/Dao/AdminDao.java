package com.onlinemail.Dao;

import java.util.List;

import com.onlinemail.bean.Admin;

public interface AdminDao {
	public List<Admin> findAll();
	public Admin findByNamePsd(String name,String psd);
	public boolean addAdmin(Admin admin);
	public boolean updateAdmin(Admin admin);
	public boolean deleteAdmin(Admin admin);
}
