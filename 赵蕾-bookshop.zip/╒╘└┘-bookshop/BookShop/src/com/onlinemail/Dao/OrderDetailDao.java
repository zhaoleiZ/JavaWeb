package com.onlinemail.Dao;

import java.util.List;

import com.onlinemail.bean.Book;
import com.onlinemail.bean.Order;
import com.onlinemail.bean.OrderDetail;

public interface OrderDetailDao {
	public List<OrderDetail> getByOrderId(Order order);
	public OrderDetail getDetailByOrderAndBook(Order order,Book book);
	public boolean updateDetail(OrderDetail od);
	public boolean saveDetail(OrderDetail od);
	public OrderDetail getByDetailId(int detailId);
	public boolean deleteDetail(OrderDetail od);
}
