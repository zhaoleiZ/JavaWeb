/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50506
Source Host           : localhost:3306
Source Database       : bookshop

Target Server Type    : MYSQL
Target Server Version : 50506
File Encoding         : 65001

Date: 2017-12-20 14:21:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', '赵赵', '123');
INSERT INTO `admin` VALUES ('2', '老丁', '111');
INSERT INTO `admin` VALUES ('3', '老韩', '123');
INSERT INTO `admin` VALUES ('4', '哈哈', '111');

-- ----------------------------
-- Table structure for `book`
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `booktypeid` int(11) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `images` varchar(200) DEFAULT NULL,
  `data` varchar(500) DEFAULT NULL,
  `publisher` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booktypeid` (`booktypeid`),
  CONSTRAINT `book_ibfk_2` FOREIGN KEY (`booktypeid`) REFERENCES `booktype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('2', '这才是数学', '1', '乔·博勒', '23.8', '../images/g2.jpg', '斯坦福大学数学教授，潜心钻研数学教育模式，走访英美多所中学，追踪几千名学生的数学学习情况，深度挖掘数学教学的有效方法。这种对数学教学的纵向研究方式。', '人民出版社');
INSERT INTO `book` VALUES ('3', 'Java程序设计教程（第二版）', '4', '刘慧琳', '27.86', '../images/g3.jpg', '本书循序渐进地介绍了Java语言的语法基础、开发工具、程序控制语句、面向对象的程序设计、图形用户界面编程、Java高级编程等内容。全书共12章，每章附有习题，供读者复习使用，同时针对每章内容，在人民邮电出版社网站上提供了上机指导，供读者选用。　　本书通过附加精选实例的方法，并穿插少量的设计细节和注意事项，按照实际开发流程对Java语言的程序设计进行了讲解，简明易懂，实用性强。本书可作为普通高等院校计算机及理工类专业Java相关课程的教材，同时也可供Java语言的初学者参考使用。', '人民邮电出版社');
INSERT INTO `book` VALUES ('4', '王尔德童话', '3', '奥斯卡.王尔德', '17.8', '../images/g4.jpg', '《快乐王子》讲述的是快乐王子和小燕子为帮助穷人而牺牲自己的故事。快乐王子活着的时候，在王富里每天都过得非常开心，从不知道忧愁和贫穷是什么。在他死后，被塑成雕像站在城市的上空，却看到了城市中的一切丑恶与苦难。于是，他拜托小燕子把自己身上所有值钱的东西全送给了穷人。后来，小燕子被冻死了，快乐王子也因心碎死去，但他们永远生活在天堂中了。', '中国少年儿童出版社');
INSERT INTO `book` VALUES ('5', '浮生六记', '2', '沈复', '27.2', '../images/g5.jpg', '《浮生六记》是清代文人沈复写作的自传散文。因其以真言述真情，从不刻意造作，得以浑然天成，独树一帜，达“乐而不淫，哀而不伤”之境界，深为后世文人所推崇，流传至今，已成经典。', '天津人民出版社');
INSERT INTO `book` VALUES ('6', '白鹿原', '2', '陈忠实', '27', '../images/g6.jpg', '《白鹿原》是一部渭河平原五十年变迁的雄奇史诗，一轴中国农村班斓多彩、触目惊心的长幅画卷。主人公六娶六丧，神秘的序曲预示着不祥。一个家族两代子孙，为争夺白鹿原的统治代代争斗不已，上演了一幕幕惊心动魄的活剧：巧取风水地，恶施美人计，孝子为匪，亲翁杀媳，兄弟相煎，情人反目……大革命、日寇入侵、三年内战，白鹿原翻云覆雨，王旗变幻，家仇国恨交错缠结，冤冤相报代代不已……古老的土地在新生的阵痛中颤粟。厚重深邃的思想内容，复杂多变的人物性格，跌宕曲折的故事情节，绚丽多彩的风土人情，形成作品鲜明的艺术特色和令人震撼的真实感。', '人民文学出版社');
INSERT INTO `book` VALUES ('7', '布谷鸟的蛋是谁的', '2', '东野圭吾', '33.2', '../images/g7.jpg', '承受着妻子死亡带来的沉重打击，绯田独自含辛茹苦地将女儿抚养成人。女儿傲人的天赋令她成为全日本滑雪界最耀眼的新星，也令绯田感到欣慰。然而，陌生人送来的血指纹却让绯田再次拾起那个他不愿正视的问题——“我的妻子在孩子出生之前就已经流产……”', '新星出版社');
INSERT INTO `book` VALUES ('8', '湖畔', '2', '东野圭吾', '22', '../images/2.jpg', '为了孩子的入学考试， 四个家庭来到湖边别墅进行考前集训。 丈夫的情人尾随而至，却在深夜遇害。 妻子坦白：“是我杀的。” 丈夫打算报警处理， 但邻居们竭力帮助妻子隐瞒罪行， 在众人的劝说下丈夫终于加入了毁尸灭迹的行列， 然而冷静下来他才意识到这一切非常不合情理。 当真相被揭开之时，他却已无法挣脱……', '化学工业出版社');
INSERT INTO `book` VALUES ('10', '最冷最冷的冷门知识', '1', '赵伟', '23.8', '../images/g1.jpg', '一个内涵的屌丝，通常要孜孜不倦的阅读，此书可以拓展屌丝的知识面，可显著改善社交场合中吹牛逼无力、扯淡疲软等症状，在一定程度上提高了与白富美谈笑风生的几率，熟读此书后你甚至可以像谢耳朵那样在各种场合借题发挥，*终遭到羞愤难当的众屌丝群殴。', '万卷出版社');
INSERT INTO `book` VALUES ('11', '致我们单纯的小美好', '2', '赵乾乾', '38.4', '../images/4.jpg', '江辰说：“陈小希，如果我趁你喝醉了向你求婚会不会显得很卑鄙，乘人之危？”\r\n有人说男人对女人*的赞美就是向她求婚，我对此深信不疑。于是我认真地说：“不会呀。”\r\n他点点头：“哦。”\r\n我搓搓耳朵，满心期待着他的下一句话。\r\n竟然……没有下一句话！江辰打了个哈欠趴在我的膝盖上，闭上眼。\r\n我觉得江辰的行为不符合上下文的对话逻辑，于是拍拍他的脸：“求婚呀。”\r\n他睁开眼睛看我：“你吗？”\r\n“是呀。”\r\n“好，我答应了。”他说。', '江苏文艺出版社');
INSERT INTO `book` VALUES ('12', '鸡', '4', '11', '32', '../images/3.jpg', '这是一本叫做鸡的书，今晚吃鸡，大吉大利！', '随便出版社');
INSERT INTO `book` VALUES ('13', '11', '2', '11', '111', '../images/1.jpg', '11111111111111111', '1111');

-- ----------------------------
-- Table structure for `booktype`
-- ----------------------------
DROP TABLE IF EXISTS `booktype`;
CREATE TABLE `booktype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of booktype
-- ----------------------------
INSERT INTO `booktype` VALUES ('1', '教育类');
INSERT INTO `booktype` VALUES ('2', '文学类');
INSERT INTO `booktype` VALUES ('3', '儿童类');
INSERT INTO `booktype` VALUES ('4', '科技');
INSERT INTO `booktype` VALUES ('5', '励志');
INSERT INTO `booktype` VALUES ('9', '悬疑类');

-- ----------------------------
-- Table structure for `orderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `orderdetailid` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) DEFAULT NULL,
  `bookid` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`orderdetailid`),
  KEY `orderid` (`orderid`),
  KEY `bookid` (`bookid`),
  CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `orders` (`id`),
  CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`bookid`) REFERENCES `book` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('23', '18', '2', '3');
INSERT INTO `orderdetail` VALUES ('24', '18', '3', '1');
INSERT INTO `orderdetail` VALUES ('25', '18', '5', '1');
INSERT INTO `orderdetail` VALUES ('29', '19', null, '1');
INSERT INTO `orderdetail` VALUES ('30', '19', '2', '2');
INSERT INTO `orderdetail` VALUES ('64', '41', '2', '1');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderTime` varchar(100) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('18', '2017-12-18 11:32:45', '4', '未付款');
INSERT INTO `orders` VALUES ('19', '2017-12-18 17:41:39', '2', '订单取消');
INSERT INTO `orders` VALUES ('41', '2017-12-19 15:32:12', '2', '已付款');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `telephone` varchar(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `post` varchar(6) DEFAULT NULL,
  `userimg` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('2', '赵赵', '123', '河北邯郸', '11234353634', '12314@163.com', '245356', '../images/10.jpg');
INSERT INTO `user` VALUES ('3', '丁丁', '123', '河北石家庄', '13435356644', '12314@163.com', '356564', '../images/10.jpg');
INSERT INTO `user` VALUES ('4', '老韩', '123', '河北省涿州市', '11111111111', '123123@qq.com', '111111', '../images/9.jpg');
INSERT INTO `user` VALUES ('5', '111', '111', '河北省涿州市', '11', 'zhaoleizlei@163.com', '111111', '../images/3.jpg');
