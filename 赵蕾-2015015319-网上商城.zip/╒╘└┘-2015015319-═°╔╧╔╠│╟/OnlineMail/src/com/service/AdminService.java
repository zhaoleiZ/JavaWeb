package com.service;

public class AdminService {

}
