package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.Book;
import com.bean.BookType;
import com.dao.BookDao;

public class BookService {

	private static List<Book> list= new ArrayList();
	private static BookDao bookDao = new BookDao();
	public static List<Book> getBook(){
		List<Book> list = bookDao.getBookList();
		return list;
		
	}
	public Book getBook(int id) {
		Book book = new Book();
		book = bookDao.getBook(id);
		return book;
	}
	public boolean updateBook(String images,String name,String author,int price,String typeName,String publisher,String data) {
		Book book = new Book();
		book.setAuthor(author);
		book.setBook(bookDao.getBookType(typeName));
		book.setImages(images);
		book.setName(name);
		book.setPrice(price);
		book.setPublisher(publisher);
		book.setData(data);
		if(bookDao.editorBook(book)) {
			return true;
		}
		return false;
	}
	public boolean addBook(String images,String name,String author,int price,String typeName,String publisher,String data) {
		Book book = new Book();
		book.setAuthor(author);
		book.setBook(bookDao.getBookType(typeName));
		book.setImages(images);
		book.setName(name);
		book.setPrice(price);
		book.setPublisher(publisher);
		book.setData(data);
		if(bookDao.addBook(book)) {
			return true;
		}
		return false;
		
	}
	public List<Book> getBookByName(String name) {
		List<Book> list = new ArrayList();
		list = bookDao.getBookByName(name);
		return list;
	}
	public List<String> getTypeName() {
		List<String> list = new ArrayList();
		list = bookDao.getTypeName();
		return list;
	}
	public List<Book> getBookByTypeName(String typeName){
		List<Book> list = bookDao.getBookByTypeName(typeName);
		return list;
	}
	
	public List<Book> CreateBookList(Book book){
		list.add(book);
		return list;
	}
	public List<Book> DeleteBookFromList(int id){
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getId()==id) {
				list.remove(i);
			}
		}
		return list;
	}
	public List<Book> getList(){
		return list;
	}
	public boolean deleteBook(int id) {
		if(bookDao.deleteBook(id)) {
			return true;
		}
		return false;
	}
}
