package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.Order;
import com.bean.OrderDetail;
import com.dao.OrderDao;

public class OrderService {

	private OrderDao orderDao = new OrderDao();
	public List<Order> getAllOrder(){
		List<Order> list = new ArrayList();
		list=orderDao.getAllOrder();
		return list;
	}
	public boolean addOrder(Order order) {
		if(orderDao.addOrder(order)) {
			return true;
		}
		return false;
	}
	public Order getOrder(String time,int userid) {
		Order order = orderDao.getOrderByTimeAndid(time, userid);
		return order;
	}
}
