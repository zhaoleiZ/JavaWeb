package com.service;

import java.util.List;

import com.bean.OrderDetail;
import com.dao.OrderDetailDao;

public class OrderDetailService {

	private static OrderDetailDao orderDetailDao= new OrderDetailDao();
	public boolean addOrderDetail(OrderDetail orderDetail) {
		if(orderDetailDao.addOrderDetail(orderDetail)) {
			return true;
		}
		return false;
	}
	public List<OrderDetail> getDetailById(int orderId){
		List<OrderDetail> list = orderDetailDao.getOrderDetailById(orderId);
		return list;
	}
}
