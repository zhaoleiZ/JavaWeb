package com.service;

import java.util.List;

import com.bean.User;
import com.dao.UserDao;

public class UserService {

	public UserDao userDao = new UserDao();
	public boolean register(User user) {
		if(userDao.register(user)) {
			return true;
		}
		return false;
	}
	public User getUser(String name,String password) {
		User user = userDao.getUser(name, password);
		return user;
	}
	public User getUserById(int id) {
		User user = userDao.getUserById(id);
		return user;
	}
	public List<User> getUser(){
		List list=userDao.getUser();
		return list;
	}
}
