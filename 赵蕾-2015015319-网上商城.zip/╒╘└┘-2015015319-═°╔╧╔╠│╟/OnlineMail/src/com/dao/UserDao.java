package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.Admin;
import com.bean.Book;
import com.bean.BookType;
import com.bean.User;
import com.common.DbConnection;

public class UserDao {

	//��¼
	public User getUser(String name,String password) {
		User user = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from user where user_name=? and user_password=?");
			 ps.setString(1,name);
			 ps.setString(2,password);
			 rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setUserId(rs.getInt("user_id"));
				user.setUserAddress(rs.getString("user_address"));
				user.setUserEmail(rs.getString("user_email"));
				user.setUsername(name);
				user.setUserTelephone(rs.getString("user_telephone"));
				user.setUserTelephone(rs.getString("post"));
				user.setUserPassword(password);
			}
	//		System.out.println(admin.getAdminName());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return user;
	}
	//�����û�
	public boolean register(User user) {

		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `user`(`user_name`, `user_password`, `user_address`, `user_telephone`, `user_email`, `user_post`)  VALUE (?,?,?,?,?,?)");
			 ps.setString(1,user.getUsername());
			 ps.setString(2,user.getUserPassword());
			 ps.setString(3,user.getUserAddress());
			 ps.setString(4,user.getUserTelephone());
			 ps.setString(5,user.getUserEmail());
			 ps.setString(6,user.getPost());
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	//ͨ��ID��ȡ�û�
	public User getUserById(int id) {
		User user = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from user where user_id=?");
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setPost(rs.getString("user_post"));
				user.setUserAddress(rs.getString("user_address"));
				user.setUserEmail(rs.getString("user_email"));
				user.setUserId(id);
				user.setUsername(rs.getString("user_name"));
				user.setUserPassword(rs.getString("user_password"));
				user.setUserTelephone(rs.getString("user_telephone"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return user;
	}
	//��ȡȫ���û�
		public List<User> getUser() {
			Connection connection = DbConnection.getConnection();
			PreparedStatement ps = null;
			ResultSet rs = null;
			List<User> list = new ArrayList();
			try {
				ps = connection.prepareStatement("select * from `user`");
				rs = ps.executeQuery();
				while(rs.next()) {
					User user = new User();
					user.setPost(rs.getString("user_post"));
					user.setUserAddress(rs.getString("user_address"));
					user.setUserEmail(rs.getString("user_email"));
					user.setUserId(rs.getInt("user_id"));
					user.setUsername(rs.getString("user_name"));
					user.setUserPassword(rs.getString("user_password"));
					user.setUserTelephone(rs.getString("user_telephone"));
					list.add(user);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return list;
		}
}
