package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.Book;
import com.bean.Order;
import com.bean.OrderDetail;
import com.common.DbConnection;

public class OrderDetailDao {

	private Connection connection = DbConnection.getConnection();
	//����orderDetail
	public boolean addOrderDetail(OrderDetail orderDetail) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		try {
 			 ps = connection.prepareStatement("INSERT INTO `order_detail`(`order_id`, `book_id`,`count`)  VALUE (?,?,?)");
			 ps.setInt(1,orderDetail.getOrder().getOrderId());
			 ps.setInt(2,orderDetail.getBook().getId());
			 ps.setInt(3,orderDetail.getCount());
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	//��ȡ��������
	public OrderDetail getOrderDetail() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		OrderDetail detail = null;
		try {
			ps = connection.prepareStatement("selet * from order_detail");
			rs = ps.executeQuery();
			detail = new OrderDetail();
			int orderId = rs.getInt("order_id");
			Order order = new Order();
			OrderDao orderDao = new OrderDao();
			order = orderDao.getOrderById(orderId);
			detail.setOrder(order);
			int bookid = rs.getInt("book_id");
			Book book = new Book();
			BookDao bookDao = new BookDao();
			bookDao.getBook(bookid);
			detail.setBook(book);
			detail.setCount(rs.getInt("count"));
			detail.setOrderDetailId(rs.getInt("order_detail_id"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return detail;
	}
	//ͨ��Order_id��ȡ��������
		public List<OrderDetail> getOrderDetailById(int id) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			OrderDetail detail = null;
			List<OrderDetail> list = new ArrayList();
			try {
				ps = connection.prepareStatement("selet * from order_detail where order_id=?");
				ps.setInt(1, id);
				rs = ps.executeQuery();
				detail = new OrderDetail();
				int orderId = rs.getInt("order_id");
				Order order = new Order();
				OrderDao orderDao = new OrderDao();
				order = orderDao.getOrderById(orderId);
				detail.setOrder(order);
				int bookid = rs.getInt("book_id");
				Book book = new Book();
				BookDao bookDao = new BookDao();
				bookDao.getBook(bookid);
				detail.setBook(book);
				detail.setCount(rs.getInt("count"));
				detail.setOrderDetailId(rs.getInt("order_detail_id"));
				list.add(detail);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return list;
		}
}
