package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.Admin;
import com.common.DbConnection;

public class AdminDao {

	//��¼
	public Admin getAdmin(String name,String password) {
		Admin admin = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from admin where admin_name=? and admin_password=?");
			 ps.setString(1,name);
			 ps.setString(2,password);
			 rs = ps.executeQuery();
			if(rs.next()) {
				admin = new Admin();
				admin.setAdminId(rs.getInt("admin_id"));
				admin.setAdminName(name);
				admin.setAdminPassword(password);
			}
//			System.out.println(admin.getAdminName());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return admin;
	}
	//�����¹���Ա
	public boolean register(String name,String password) {

		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `admin`(`admin_name`, `admin_password`)  VALUE (?,?)");
			 ps.setString(1,name);
			 ps.setString(2,password);
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
}
