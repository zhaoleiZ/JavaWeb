package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.Book;
import com.bean.BookType;
import com.common.DbConnection;

public class BookDao {

	//ͨ������������ȡͼ��
	public List<Book> getBookByName(String name) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Book> list = new ArrayList();
		try {
			ps = connection.prepareStatement("select * from book,book_type where book_name like ? and book.type_id = book_type.type_id");
			ps.setString(1,"%"+name+"%");
			rs = ps.executeQuery();
			if(rs.next()) {
				Book book = new Book();
				BookType bookType=new BookType();
				book.setId(rs.getInt("book_id"));
				book.setAuthor(rs.getString("author"));
				bookType.setTypeId(rs.getInt("type_id"));
				bookType.setTypeName(rs.getString("type_name"));
				book.setBook(bookType);
				book.setName(rs.getString("book_name"));
				book.setPrice(rs.getInt("price"));
				book.setImages(rs.getString("images"));
				book.setPublisher(rs.getString("publisher"));
				book.setData(rs.getString("book_data"));
				list.add(book);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	//��ȡȫ��ͼ��
	public List<Book> getBookList() {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List <Book>list = new ArrayList();
		try {
			ps = connection.prepareStatement("select * from book,book_type where book.type_id=book_type.type_id");
			rs = ps.executeQuery();
			while(rs.next()) {
				Book book = new Book();
				BookType bookType=new BookType();
				book.setId(rs.getInt("book_id"));
				book.setAuthor(rs.getString("author"));
				bookType.setTypeId(rs.getInt("type_id"));
				bookType.setTypeName(rs.getString("type_name"));
				book.setBook(bookType);
				book.setName(rs.getString("book_name"));
				book.setPrice(rs.getInt("price"));
				book.setImages(rs.getString("images"));
				book.setPublisher(rs.getString("publisher"));
				book.setData(rs.getString("book_data"));
				list.add(book);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
		
	}
	//ͨ��id��ȡ
	public Book getBook(int id) {
		Book book = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from book,book_type where book.type_id=book_type.type_id and book_id=?");
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(rs.next()) {
				book = new Book();
				BookType bookType=new BookType();
				book.setId(rs.getInt("book_id"));
				book.setAuthor(rs.getString("author"));
				bookType.setTypeId(rs.getInt("type_id"));
				bookType.setTypeName(rs.getString("type_name"));
				book.setBook(bookType);
				book.setName(rs.getString("book_name"));
				book.setPrice(rs.getInt("price"));
				book.setImages(rs.getString("images"));
				book.setPublisher(rs.getString("publisher"));
				book.setData(rs.getString("book_data"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return book;
		
	}
	//�༭
	public boolean editorBook(Book book) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement("update book set book_name=?,author=?,type_id=?,price=?,image=?,publisher=?,book_data=? ");
			ps.setString(1, book.getName());
			ps.setString(2, book.getAuthor());
			ps.setInt(3, book.getBook().getTypeId());
			ps.setInt(4,book.getPrice());
			ps.setString(5, book.getImages());
			ps.setString(6, book.getPublisher());
			ps.setString(7, book.getData());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	//����ͼ������
	public boolean addBookType(BookType book) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `book_type`(`type_name`,`type_id`)  VALUE (?,?)");
			 ps.setString(1,book.getTypeName());
			 ps.setInt(2,book.getTypeId());
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	//����
	public boolean addBook(Book book) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `book`(`book_name`, `author`,`type_id`,'price','image','publisher','data')  VALUE (?,?,?,?,?,?)");
			 ps.setString(1,book.getName());
			 ps.setString(2,book.getAuthor());
			 ps.setInt(3,book.getId());
			 ps.setInt(4,book.getPrice());
			 ps.setString(5,book.getImages());
			 ps.setString(6,book.getPublisher());
			 ps.setString(7,book.getData());
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	//ɾ��
	public boolean deleteBook(int id) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		
			 try {
				 ps = connection.prepareStatement("delete from book where id=?");
				 ps.setInt(1,id);
				 ps.execute();
				 return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			 return false;
	}
	//��ȡbookType����
	public BookType getBookType(String name) {
		BookType bookType = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from book_type where type_name=?");
			ps.setString(1, name);
			rs = ps.executeQuery();
			if(rs.next()) {
				bookType = new BookType();
				bookType.setTypeId(rs.getInt("type_id"));
				bookType.setTypeName(name);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bookType;
	}
	//��ȡtypeName
	public List<String> getTypeName() {
		List<String> list = new ArrayList();
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select type_name from book_type");
			rs = ps.executeQuery();
			while(rs.next()) {
				String name = rs.getString("type_name");
				list.add(name);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	public List<Book> getBookByTypeName(String typeName){
		List<Book> list = new ArrayList();
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from book_type,book where book_type.type_id=book.type_id and type_name=?");
			ps.setString(1, typeName);
			rs = ps.executeQuery();
			while(rs.next()) {
				Book book = new Book();
				BookType bookType = new BookType();
				book.setId(rs.getInt("book_id"));
				book.setAuthor(rs.getString("author"));
				bookType.setTypeId(rs.getInt("type_id"));
				bookType.setTypeName(rs.getString("type_name"));
				book.setBook(bookType);
				book.setName(rs.getString("book_name"));
				book.setPrice(rs.getInt("price"));
				book.setImages(rs.getString("images"));
				book.setPublisher(rs.getString("publisher"));
				book.setData(rs.getString("book_data"));
				list.add(book);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
}
