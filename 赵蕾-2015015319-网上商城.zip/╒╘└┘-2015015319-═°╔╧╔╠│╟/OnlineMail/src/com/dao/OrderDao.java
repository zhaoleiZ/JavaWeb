package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.Book;
import com.bean.BookType;
import com.bean.Order;
import com.bean.OrderDetail;
import com.common.DbConnection;

public class OrderDao {

	private Connection connection = DbConnection.getConnection();
	//��ȡȫ������
	public List<Order> getAllOrder() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List <Order>list = new ArrayList();
		try {
			ps = connection.prepareStatement("select * from `order`");
			rs = ps.executeQuery();
			while(rs.next()) {
				Order order = new Order();
				order.setOrderId(rs.getInt("order_id"));
				order.setOrderTime(rs.getString("order_time"));
				order.setUserId(rs.getInt("user_id"));
				list.add(order);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	//ͨ��id��ȡ����
	public Order getOrderById(int orderId) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Order order = null;
		try {
			ps=connection.prepareStatement("select * from `order` where id=?");
			ps.setInt(1, orderId);
			rs = ps.executeQuery();
			order.setOrderId(rs.getInt("order_id"));
			order.setOrderTime(rs.getString("order_time"));
			order.setUserId(rs.getInt("user_id"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return order;
	}
	//�½�����
	public boolean addOrder(Order order) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `order`(`user_id`,`order_time`)  VALUE (?,?)");
			 ps.setInt(1,order.getUserId());
			 ps.setString(2,order.getOrderTime());
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	//ͨ��ʱ�䣬�û�ID���Ҷ���
	public Order getOrderByTimeAndid(String time,int userid) {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Order order = null;
		try {
			ps = connection.prepareStatement("select * from order where order_time=? and user_id=?");
			ps.setString(1, time);
			ps.setInt(2, userid);
			rs = ps.executeQuery();
			if(rs.next()) {
				order = new Order();
				order.setOrderId(rs.getInt("order_id"));
				order.setOrderTime(time);
				order.setUserId(userid);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
//				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return order;
	}
	
}
