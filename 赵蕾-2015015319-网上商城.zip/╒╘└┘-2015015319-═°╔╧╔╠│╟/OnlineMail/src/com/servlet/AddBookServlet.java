package com.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.oreilly.servlet.MultipartRequest;
import com.service.BookService;

/**
 * Servlet implementation class AddBookServlet
 */
@WebServlet("/AddBookServlet")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String images = (String)request.getParameter("images");
		String bookName = (String) request.getParameter("name");
		String author = (String) request.getParameter("author");
		String str = (String)request.getParameter("price");
		int price = Integer.parseInt(str);
		String typeName = (String) request.getParameter("type");
		String publisher = (String) request.getParameter("publisher");
		String data = (String)request.getParameter("data");
		
		ServletContext s1 = this.getServletContext();
		String path = s1.getRealPath("images");
		MultipartRequest mr = new MultipartRequest(request,path,1024*1024,"UTF-8");
		
		DiskFileItemFactory dff= new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(dff);
		String realPath = getServletContext().getRealPath("image");
		try {
			List<FileItem> fileitems = sfu.parseRequest(request);
			for(FileItem fi:fileitems) {
				if(fi.isFormField()) {
					String name = fi.getString("UTF-8");
					request.setAttribute("name", name);
				}else {
					String name = fi.getName();
					int start = name.lastIndexOf("\\");
					name.substring(start+1);
					System.out.println(name);
					fi.write(new File(realPath+"\\"+name.substring(start+1)));
					request.setAttribute("image",name.substring(start+1));	
					}
				}
		}catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BookService bookService = new BookService();
		if(bookService.addBook(images, bookName, author, price, typeName, publisher,data)) {
			response.sendRedirect("admin/success.jsp");
		}else {
			response.sendRedirect("admin/404.html");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
