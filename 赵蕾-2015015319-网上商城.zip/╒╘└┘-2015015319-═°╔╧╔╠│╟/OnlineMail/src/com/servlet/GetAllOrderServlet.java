package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Order;
import com.bean.OrderDetail;
import com.service.OrderDetailService;
import com.service.OrderService;

/**
 * Servlet implementation class GetAllOrderServlet
 */
@WebServlet("/GetAllOrderServlet")
public class GetAllOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAllOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		OrderService orderService = new OrderService();
		OrderDetailService orderDetailService = new OrderDetailService();
		List<Order> list = orderService.getAllOrder();
		List<OrderDetail> detailList = new ArrayList();
		for(int i=0;i<list.size();i++) {
			List<OrderDetail> detailList_1 = orderDetailService.getDetailById(list.get(i).getOrderId());
			for(int j=0;j<detailList_1.size();j++) {
				detailList.add(detailList_1.get(j));
			}
		}
		request.getSession().setAttribute("list", detailList);
		response.sendRedirect("admin/order.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
