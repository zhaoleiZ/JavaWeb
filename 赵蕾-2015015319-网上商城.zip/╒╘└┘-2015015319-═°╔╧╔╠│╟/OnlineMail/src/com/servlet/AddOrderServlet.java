package com.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Book;
import com.bean.Order;
import com.bean.OrderDetail;
import com.service.BookService;
import com.service.OrderDetailService;
import com.service.OrderService;

/**
 * Servlet implementation class AddOrderServlet
 */
@WebServlet("/AddOrderServlet")
public class AddOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		BookService bookService = new BookService();
		List<Book> list = bookService.getList();
		//��������
		Order order = new Order();
		OrderDetail orderDetail = new OrderDetail();
		//ʱ��
		Date date = new Date();
		SimpleDateFormat ft = new SimpleDateFormat ("yyyy��MM��dd��  hh:mm:ss");
		String orderTime = ft.format(date);
		order.setOrderTime(orderTime);
		
		int id = Integer.parseInt(request.getParameter("id"));
		order.setUserId(id);
		OrderService orderService = new OrderService();
		System.out.println("AddOrderServlet userId_1:"+order.getOrderId());
		orderService.addOrder(order);
		System.out.println("AddOrderServlet:order:"+order.getOrderId());
		Order thisOrder = orderService.getOrder(orderTime, id);
		//������������
		int count=1;
		List <Book>bookList = list;
		for(int i=0;i<bookList.size();i++) {
			for(int j=1;j<bookList.size();j++) {
				if(bookList.get(i).getId()==bookList.get(j).getId()) {
					count++;
					bookList.remove(j);
				}
			}
			orderDetail.setCount(count);
			orderDetail.setBook(bookList.get(i));
			orderDetail.setOrder(order);
			OrderDetailService orderDetailService = new OrderDetailService();
			orderDetailService.addOrderDetail(orderDetail);
		}
		list.removeAll(list);
		count = 0;
		request.getSession().setAttribute("count",count);
		response.sendRedirect("user/shoppingCar.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
